sap.ui.define([
	"zsapreunit/test/unit/controller/MainView.controller"
], function () {
	"use strict";
});
