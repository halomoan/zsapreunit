/* global QUnit */

sap.ui.require(["zsapreunit/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
